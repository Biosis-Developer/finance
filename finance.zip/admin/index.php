<?php
//just placeholder, it will be used to separate admin login from default login. default login will be used for client portal login
header('location: ../?ng=admin/');
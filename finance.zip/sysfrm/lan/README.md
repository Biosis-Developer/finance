# Language Files for iBilling

We need Contributor for iBilling ( http://codecanyon.net/item/ibilling-accounting-and-billing-software/11021678 ) Translation

### Version
2.4.0

### Sample Language Lines

```php
$_L['Invoice'] = 'Invoice';
$_L['Send Email'] = 'Send Email';
$_L['Invoice Created'] = 'Invoice Created';
$_L['Invoice Payment Reminder'] = 'Invoice Payment Reminder';
$_L['Invoice Overdue Notice'] = 'Invoice Overdue Notice';
$_L['Invoice Payment Confirmation'] = 'Invoice Payment Confirmation';
$_L['Invoice Refund Confirmation'] = 'Invoice Refund Confirmation';
$_L['Mark As'] = 'Mark As';
$_L['Partially Paid'] = 'Partially Paid';
$_L['Add Payment'] = 'Add Payment';
$_L['Preview'] = 'Preview';
$_L['PDF'] = 'PDF';
$_L['View PDF'] = 'View PDF';
$_L['Print'] = 'Print';
$_L['Subtotal'] = 'Subtotal';
$_L['Grand Total'] = 'Grand Total';
$_L['Search by Name'] = 'Search by Name';
$_L['Search'] = 'Search';
$_L['Add New Contact'] = 'Add New Contact';
$_L['Filter by Tags'] = 'Filter by Tags';
```
<img src="http://www.ibilling.io/wp-content/uploads/2015/03/localisation-settings.jpg">


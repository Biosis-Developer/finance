<?php
$db_host     = 'localhost';
$db_user     = 'root';
$db_password = '';
$db_name     = 'finance';
define('APP_URL', 'http://localhost/finance');
$_app_stage = 'Live'; /* Não altere esta linha */

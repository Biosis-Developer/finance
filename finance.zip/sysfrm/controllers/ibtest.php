<?php
// Do Not Remove this file
$data = array( 'ibilling' => 'yes');
header('Content-type: application/json');
echo json_encode( $data ); 
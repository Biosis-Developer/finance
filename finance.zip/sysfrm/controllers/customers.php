<?php
//alias Contacts
$myCtrl = 'customers';
require('sysfrm/controllers/contacts.php');
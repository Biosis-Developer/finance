<?php
class Braintree_Exception_InvalidSignature extends Braintree_Exception
{

}
